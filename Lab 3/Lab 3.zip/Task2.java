import java.io.File;
import java.util.Scanner;

class Task2
{
    public static void main(String[] args) throws java.io.FileNotFoundException
    {
        int x = 0;

        //while the condition is true, keep looping until the condition isn't true
        while (x < 11) {
            System.out.println("Looping hardcore dude");
            x++;
        }
        System.out.println("Not looping anymore feels bad");

        //The Scanner .hasNext() function checks to see if there is a word
    }
}